# -*- coding: utf-8 -*-
"""
JigPuzzle Solver - Single File Edition
---------------------------------------
این فایل کاملاً خودکفاست:
- اپ Kivy در همین فایل
- buildozer.spec را در اولین اجرا خودکار می‌سازد
- فقط کافی است به Buildozer بدهی تا APK بسازد

اجرا روی PC:      python main.py
اجرا روی اندروید:  python main.py  (با Pydroid3)
ساخت APK:         buildozer -v android debug
"""

import os
from io import BytesIO
from kivy.app import App
from kivy.core.text import LabelBase, DEFAULT_FONT
from kivy.utils import platform
from kivy.clock import Clock
from kivy.core.image import Image as CoreImage
from kivy.graphics import Color, Rectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.image import Image as KivyImage
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.spinner import Spinner
from PIL import Image, ImageDraw

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
except Exception:          # اگر نصب نبود، متن همان‌طور نمایش داده می‌شود
    arabic_reshaper = None

_HERE = os.path.dirname(os.path.abspath(__file__))
_FONT = os.path.join(_HERE, 'font.ttf')
if os.path.exists(_FONT):
    # فونت پیش‌فرض Kivy حروف فارسی ندارد؛ این فونت جایگزینش می‌شود
    LabelBase.register(DEFAULT_FONT, _FONT)


def fa(text):
    """متن فارسی را برای نمایش درست در Kivy آماده می‌کند (اتصال حروف + راست‌به‌چپ)."""
    if arabic_reshaper is None:
        return text
    try:
        return get_display(arabic_reshaper.reshape(text))
    except Exception:
        return text


# ============================================================
#  بخش ۱: تولید خودکار buildozer.spec
# ============================================================
BUILDOZER_SPEC = """[app]
title = JigPuzzle Solver
package.name = jigsolver
package.domain = com.jigsolver

source.dir = .
source.include_exts = py,png,jpg,kv,atlas
version = 1.0

requirements = python3,kivy==2.3.0,pillow,plyer,android

orientation = portrait
fullscreen = 0

android.api = 33
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.permissions = READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE, READ_MEDIA_IMAGES
android.allow_backup = True

[buildozer]
log_level = 2
warn_on_root = 1
"""


def ensure_buildozer_spec():
    """اگر buildozer.spec نیست، بسازش (فقط روی کامپیوتر)."""
    if platform == 'android':
        return
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'buildozer.spec')
    if not os.path.exists(path):
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(BUILDOZER_SPEC)
            print(f"[+] buildozer.spec created at: {path}")
        except Exception as e:
            print(f"[!] Could not write buildozer.spec: {e}")


# ============================================================
#  بخش ۲: الگوریتم حل پازل
# ============================================================
class JigSolver:
    """پازل را با تطبیق لبه‌های مجاور حل می‌کند."""

    def __init__(self, image, rows, cols):
        self.rows = rows
        self.cols = cols
        self.image = image.convert('RGB')
        self.pieces = self._split_grid()

    def _split_grid(self):
        w, h = self.image.size
        pw, ph = w // self.cols, h // self.rows
        pieces = []
        for r in range(self.rows):
            for c in range(self.cols):
                pieces.append(self.image.crop((c*pw, r*ph, (c+1)*pw, (r+1)*ph)))
        return pieces

    def _edge(self, piece, side, n=20):
        w, h = piece.size
        px = piece.load()
        if side == 'L':
            return [px[0, min(h-1, int(h*i/n))] for i in range(n)]
        if side == 'R':
            return [px[w-1, min(h-1, int(h*i/n))] for i in range(n)]
        if side == 'T':
            return [px[min(w-1, int(w*i/n)), 0] for i in range(n)]
        if side == 'B':
            return [px[min(w-1, int(w*i/n)), h-1] for i in range(n)]

    @staticmethod
    def _diff(a, b):
        return sum(abs(x[0]-y[0]) + abs(x[1]-y[1]) + abs(x[2]-y[2]) for x, y in zip(a, b))

    def solve(self):
        n = len(self.pieces)
        if n == 0:
            return []

        R, D = {}, {}
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                R[(i, j)] = self._diff(self._edge(self.pieces[i], 'R'),
                                       self._edge(self.pieces[j], 'L'))
                D[(i, j)] = self._diff(self._edge(self.pieces[i], 'B'),
                                       self._edge(self.pieces[j], 'T'))

        grid = [[-1]*self.cols for _ in range(self.rows)]
        used = {0}
        grid[0][0] = 0

        # ردیف اول: با تطبیق لبه راست-چپ
        for c in range(1, self.cols):
            prev = grid[0][c-1]
            best, bs = -1, float('inf')
            for j in range(n):
                if j in used:
                    continue
                if R[(prev, j)] < bs:
                    bs, best = R[(prev, j)], j
            grid[0][c] = best
            used.add(best)

        # بقیه ردیف‌ها: ترکیب بالا و چپ
        for r in range(1, self.rows):
            for c in range(self.cols):
                above = grid[r-1][c]
                best, bs = -1, float('inf')
                for j in range(n):
                    if j in used:
                        continue
                    s = D[(above, j)]
                    if c > 0:
                        s += R[(grid[r][c-1], j)]
                    if s < bs:
                        bs, best = s, j
                grid[r][c] = best
                used.add(best)

        return [(grid[r][c], r, c) for r in range(self.rows) for c in range(self.cols)]


def pil_to_texture(pil_img):
    """تبدیل تصویر PIL به texture قابل نمایش در Kivy."""
    buf = BytesIO()
    pil_img.save(buf, format='png')
    buf.seek(0)
    return CoreImage(buf, ext='png').texture


# ============================================================
#  بخش ۳: اپلیکیشن
# ============================================================
class JigApp(App):
    title = "JigPuzzle Solver"

    def build(self):
        self.image = None
        self.solver = None
        self.steps = []
        self.step_idx = 0
        self.play_event = None
        self._tex = None

        root = BoxLayout(orientation='vertical', padding=dp(6), spacing=dp(6))
        with root.canvas.before:
            Color(0.08, 0.08, 0.1, 1)
            self.bg = Rectangle(pos=root.pos, size=root.size)
        root.bind(pos=lambda *a: setattr(self.bg, 'pos', root.pos),
                  size=lambda *a: setattr(self.bg, 'size', root.size))

        # ---------- نوار بالا ----------
        top = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(4))
        top.add_widget(Button(text=fa("انتخاب عکس"), on_press=self.pick_file,
                              background_color=(0.2, 0.5, 0.9, 1)))
        top.add_widget(Label(text=fa("ردیف"), size_hint_x=None, width=dp(45)))
        self.rows_spin = Spinner(text='3', values=[str(i) for i in range(2, 9)],
                                 size_hint_x=None, width=dp(55))
        top.add_widget(self.rows_spin)
        top.add_widget(Label(text=fa("ستون"), size_hint_x=None, width=dp(50)))
        self.cols_spin = Spinner(text='3', values=[str(i) for i in range(2, 9)],
                                 size_hint_x=None, width=dp(55))
        top.add_widget(self.cols_spin)
        top.add_widget(Button(text=fa("حل"), on_press=self.solve,
                              background_color=(0.2, 0.7, 0.3, 1)))
        root.add_widget(top)

        # ---------- ناحیه تصویر ----------
        self.image_widget = KivyImage(allow_stretch=True, keep_ratio=True)
        root.add_widget(self.image_widget)

        # ---------- وضعیت ----------
        self.status = Label(text=fa("عکس را بارگذاری کن"),
                            size_hint_y=None, height=dp(32))
        root.add_widget(self.status)

        # ---------- کنترل‌ها ----------
        bottom = BoxLayout(size_hint_y=None, height=dp(60), spacing=dp(4))
        bottom.add_widget(Button(text="<<", on_press=self.prev_step, font_size=dp(24)))
        self.play_btn = Button(text=fa("پخش"), on_press=self.toggle_play,
                               font_size=dp(16),
                               background_color=(0.2, 0.6, 0.9, 1))
        bottom.add_widget(self.play_btn)
        bottom.add_widget(Button(text=">>", on_press=self.next_step, font_size=dp(24)))
        bottom.add_widget(Button(text=fa("ریست"), on_press=self.reset, font_size=dp(24),
                                 background_color=(0.6, 0.3, 0.3, 1)))
        root.add_widget(bottom)

        return root

    # ---------- انتخاب فایل ----------
    def pick_file(self, *args):
        try:
            from plyer import filechooser
            filechooser.open_file(on_selection=self._on_selected,
                                  filters=[("Images", "*.png", "*.jpg", "*.jpeg")])
        except Exception:
            self._fallback_filechooser()

    def _on_selected(self, selection):
        if selection:
            self._load_path(selection[0])

    def _fallback_filechooser(self):
        start = '/'
        for path in ['/storage/emulated/0/DCIM',
                     '/storage/emulated/0/Pictures',
                     '/storage/emulated/0/Download',
                     '/sdcard/']:
            if os.path.exists(path):
                start = path
                break

        content = BoxLayout(orientation='vertical', spacing=dp(4))
        fc = FileChooserListView(path=start, filters=['*.png', '*.jpg', '*.jpeg'])
        content.add_widget(fc)
        btns = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(4))
        popup = Popup(title=fa("انتخاب عکس"), content=content, size_hint=(0.95, 0.95))

        def choose(*a):
            if fc.selection:
                popup.dismiss()
                self._load_path(fc.selection[0])

        btns.add_widget(Button(text=fa("انتخاب"), on_press=choose))
        btns.add_widget(Button(text=fa("لغو"), on_press=lambda *a: popup.dismiss()))
        content.add_widget(btns)
        popup.open()

    def _load_path(self, path):
        try:
            img = Image.open(path).convert('RGB')
            img.thumbnail((1600, 1600))   # عکس‌های بزرگ گوشی را سبک می‌کند
            self.image = img
            self.solver = None
            self.steps = []
            self.step_idx = 0
            self._tex = pil_to_texture(self.image)
            self.image_widget.texture = self._tex
            self.status.text = fa(f"بارگذاری شد: {os.path.basename(path)}")
        except Exception as e:
            self.status.text = fa(f"خطا: {e}")

    # ---------- حل ----------
    def solve(self, *args):
        if not self.image:
            self.status.text = fa("اول عکس را بارگذاری کن")
            return
        try:
            rows = int(self.rows_spin.text)
            cols = int(self.cols_spin.text)
            self.solver = JigSolver(self.image, rows, cols)
            self.steps = self.solver.solve()
            self.step_idx = 0
            self.render()
        except Exception as e:
            self.status.text = fa(f"خطا در حل: {e}")

    def render(self):
        if not self.solver:
            return
        R, C = self.solver.rows, self.solver.cols
        base = self.solver.image
        pw, ph = base.width // C, base.height // R
        out = Image.new('RGB', base.size, (25, 25, 25))
        d = ImageDraw.Draw(out)

        for i in range(R+1):
            d.line([(0, i*ph), (C*pw, i*ph)], fill=(70, 70, 70))
        for i in range(C+1):
            d.line([(i*pw, 0), (i*pw, R*ph)], fill=(70, 70, 70))

        for k in range(min(self.step_idx + 1, len(self.steps))):
            pidx, r, c = self.steps[k]
            out.paste(self.solver.pieces[pidx], (c*pw, r*ph))
            if k == self.step_idx:
                d.rectangle([c*pw, r*ph, (c+1)*pw, (r+1)*ph],
                            outline=(0, 255, 100), width=5)
            d.text((c*pw + 6, r*ph + 6), str(pidx), fill=(255, 255, 0))

        self._tex = pil_to_texture(out)
        self.image_widget.texture = self._tex

        if self.step_idx < len(self.steps):
            pidx, r, c = self.steps[self.step_idx]
            self.status.text = fa(f"مرحله {self.step_idx+1}/{len(self.steps)} — "
                                  f"قطعه {pidx} → ردیف {r+1}، ستون {c+1}")

    # ---------- کنترل‌ها ----------
    def next_step(self, *args):
        if self.step_idx < len(self.steps) - 1:
            self.step_idx += 1
            self.render()

    def prev_step(self, *args):
        if self.step_idx > 0:
            self.step_idx -= 1
            self.render()

    def toggle_play(self, *args):
        if self.play_event:
            self.play_event.cancel()
            self.play_event = None
            self.play_btn.text = fa("پخش")
        else:
            if not self.steps:
                self.status.text = fa("اول دکمه حل را بزن")
                return
            self.play_btn.text = fa("توقف")
            self.play_event = Clock.schedule_interval(self._auto_step, 0.8)

    def _auto_step(self, dt):
        if self.step_idx < len(self.steps) - 1:
            self.next_step()
        else:
            self.toggle_play()

    def reset(self, *args):
        if self.play_event:
            self.play_event.cancel()
            self.play_event = None
        self.play_btn.text = fa("پخش")
        self.step_idx = 0
        if self.solver:
            self.render()
        elif self.image:
            self._tex = pil_to_texture(self.image)
            self.image_widget.texture = self._tex
        self.status.text = fa("ریست شد")


# ============================================================
#  اجرا
# ============================================================
if __name__ == '__main__':
    ensure_buildozer_spec()
    JigApp().run()